package com.ibm.training.fitnesstrackingapp.reset;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
	
	@Id
	String email;
	String fullName, mobileNumber, password, gender;
	String dateOfBirth, subscriptionType, securityQuestion, answer;
	int height, weight;
	
	User(){}

	
	public String getSecurityQuestion() {
		return securityQuestion;
	}


	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public String getSubscriptionType() {
		return subscriptionType;
	}

	public User(String email, String fullName, String mobileNumber, String password, String gender, String dateOfBirth,
			String subscriptionType, String securityQuestion, String answer, int height, int weight) {
		this.email = email;
		this.fullName = fullName;
		this.mobileNumber = mobileNumber;
		this.password = password;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.subscriptionType = subscriptionType;
		this.securityQuestion = securityQuestion;
		this.answer = answer;
		this.height = height;
		this.weight = weight;
	}


	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
}
