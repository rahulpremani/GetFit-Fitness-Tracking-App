package com.ibm.training.fitnesstrackingapp.reset;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface ResetPasswordRepository extends CrudRepository<User, String>{
	
	@Query(value = "Select security_question from user where email= ?1", nativeQuery = true)
	String findSecurityQuestion(String email);
	
	User findByEmail(String email);
}
