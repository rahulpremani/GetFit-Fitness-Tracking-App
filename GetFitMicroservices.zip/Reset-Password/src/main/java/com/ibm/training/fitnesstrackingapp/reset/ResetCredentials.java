package com.ibm.training.fitnesstrackingapp.reset;

public class ResetCredentials {

	String answer;
	String newPassword, email;
	
	public ResetCredentials() {}
	
	public ResetCredentials(String answer, String newPassword, String email) {
		this.answer = answer;
		this.newPassword = newPassword;
		this.email = email;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
}
