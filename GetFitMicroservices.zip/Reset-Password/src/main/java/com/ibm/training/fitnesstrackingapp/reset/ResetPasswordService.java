package com.ibm.training.fitnesstrackingapp.reset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class ResetPasswordService {

	@Autowired
	ResetPasswordRepository resetPasswordRepo;
	
	@Autowired
	BCryptPasswordEncoder encoder;
	
	String userExists(String email) {
		if(resetPasswordRepo.findByEmail(email) != null) {
			return "Exists";
		}
		return "User doesn't exist.";
	}
	
	String userSecurityQuestion(String email) {
		return resetPasswordRepo.findSecurityQuestion(email);
	}
	
	String resetPassword(ResetCredentials credentials) {
		
		User user = resetPasswordRepo.findByEmail(credentials.getEmail());
		
		if(user.getAnswer().equals(credentials.getAnswer())) {
			user.setPassword(encoder.encode(credentials.getNewPassword()));
			resetPasswordRepo.save(user);
			return "Password Updated Successfully";
		} 
		return "Invalid Answer";
	}
	
	String resetOldPassword(ResetOldPassword resetOldPasswordCredentials) {
	
		User user = resetPasswordRepo.findByEmail(resetOldPasswordCredentials.getEmail());
		
		if(encoder.matches(resetOldPasswordCredentials.getOldPassword(), user.getPassword())) {
			user.setPassword(encoder.encode(resetOldPasswordCredentials.getNewPassword()));
			resetPasswordRepo.save(user);
			return "Password Reseted.";
		}
		return "Old Password Doesn't Match";
		
	}
}
