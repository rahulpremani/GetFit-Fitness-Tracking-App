package com.ibm.training.fitnesstrackingapp.reset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ResetPasswordController {

	@Autowired
	ResetPasswordService resetPasswordService;
	
	@RequestMapping("/user-exists/{email}")
	String userExists(@PathVariable String email) {
		return resetPasswordService.userExists(email);
	}
	
	@RequestMapping("/security-question/{email}")
	String userSecurityQuestion(@PathVariable String email) {
		return resetPasswordService.userSecurityQuestion(email);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/reset-password")
	String resetPassword(@RequestBody ResetCredentials credentials) {
		return resetPasswordService.resetPassword(credentials);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/reset-old-password")
	String resetOldPassword(@RequestBody ResetOldPassword resetOldPasswordCredentials) {
		return resetPasswordService.resetOldPassword(resetOldPasswordCredentials);
	}
}
