package com.ibm.training.fitnesstrackingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtilityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
