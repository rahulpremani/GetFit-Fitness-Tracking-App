package com.ibm.training.fitnesstrackingapp.utility;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, String>{

	@Query(value = "Select subscription_type from user where email= ?1", nativeQuery = true)
	String findByEmail(String email);
}
