package com.ibm.training.fitnesstrackingapp.utility;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UtilityService {

	@Autowired
	UserRepository repo;
	
	String userSubscription(String email) {
		return repo.findByEmail(email);
	}

	public String updateUserSubscription(String email, String subscriptionType) {
		Optional<User> op = repo.findById(email);
		User user = op.get();
		user.setSubscriptionType(subscriptionType);
		repo.save(user);
		return "Updated Subscription";
	}
}
