package com.ibm.training.fitnesstrackingapp.registration;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sendgrid.Content;
import com.sendgrid.Email;
import com.sendgrid.Mail;
import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.SendGrid;

@Service
public class SendGridEmailService {

	private SendGrid sendGridClient;

	@Autowired
	public SendGridEmailService(SendGrid sendGridClient) {
		this.sendGridClient = sendGridClient;
	}

	void sendEmail(String email) throws IOException {
		Email from = new Email("admin@get-fit.com");
		String subject = "Successfully Registered";
		Email to = new Email(email);
		Content content = new Content("text/plain",
				"You have successfully created your profile on GET FIT. Stay connected for recommended daily regime and fitness.");
		Mail mail = new Mail(from, subject, to, content);

		Request request = new Request();

		try {
			request.setMethod(Method.POST);
			request.setEndpoint("mail/send");
			request.setBody(mail.build());
			sendGridClient.api(request);
		} catch (IOException ex) {
			throw ex;
		}
	}

}
