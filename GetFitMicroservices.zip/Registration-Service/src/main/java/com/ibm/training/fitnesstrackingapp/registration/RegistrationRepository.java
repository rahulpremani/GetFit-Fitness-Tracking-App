package com.ibm.training.fitnesstrackingapp.registration;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;


public interface RegistrationRepository extends CrudRepository<User, String> {

	List<User> findByEmail(String email);

	@Query(value = "select weight from user where email = :email", nativeQuery = true)
	Integer fetchWeightByEmail(@Param(value = "email") String email);

	@Query(value = "select full_name from user where email = :email", nativeQuery = true)
	String findNameByEmail(@Param(value = "email") String email);

	@Query(value = "select full_name, email, mobile_number, height, weight from user where email = :email", nativeQuery = true)
	Object fetchDetailsByEmail(@Param(value = "email") String email);

	@Transactional
	@Modifying
	@Query(value = "update user set mobile_number = :mobilenumber, height = :height, "
			+ "weight = :weight where email = :email ", nativeQuery = true)
	void updateDetails(@Param(value = "mobilenumber") String mobileNumber,@Param(value = "height") int height, @Param(value = "weight") int weight, 
			@Param(value = "email") String email);

	@Query(value = "select gender from user where email = :email", nativeQuery = true)
	List<String> fetchGenderByEmail(String email);

}
 