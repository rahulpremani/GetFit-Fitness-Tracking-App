package com.ibm.training.fitnesstrackingapp.registration;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {

	@Autowired
	RegistrationRepository repo;
	
	@Autowired
	SendGridEmailService emailService;
	
	public String registerUser(User user) {
		if(repo.findByEmail(user.getEmail()).size()==1) {
			return "true";
		}
		
		repo.save(user);
		try {
			emailService.sendEmail(user.getEmail());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "false";
	}

	public Integer getWeight(String email) {
		return repo.fetchWeightByEmail(email);
	}

	public String getName(String email) {
		return repo.findNameByEmail(email);
	}

	public Object getDetails(String email) {
		return repo.fetchDetailsByEmail(email);
	}

	public void updateDetails(User user) {
		repo.updateDetails(user.getMobileNumber(), user.getHeight(), user.getWeight(), user.getEmail());
		
	}

	public List<String> getGender(String email) {
		return repo.fetchGenderByEmail(email);
	}
}
