package com.ibm.training.fitnesstrackingapp.registration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/register")
public class RegistrationController {

	@Autowired
	RegistrationService service;
	
	@Autowired
	BCryptPasswordEncoder encoder;
	
	@RequestMapping(method = RequestMethod.POST, value = "/users")
	String registerUser(@RequestBody User user){
		user.setPassword(encoder.encode(user.getPassword()));
		return service.registerUser(user);
	}
	
	@RequestMapping("users/{email}")
	Integer getWeight(@PathVariable String email) {
		return service.getWeight(email);
	}
	
	@RequestMapping("users/name/{email}")
	String getName(@PathVariable String email) {
		return service.getName(email);
	}
	
	@RequestMapping("details/{email}")
	Object getDetails(@PathVariable String email) {
		return service.getDetails(email);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "update/users")
	void updateDetails(@RequestBody User user) {
		service.updateDetails(user);
	}
	
	@RequestMapping("users/gender/{email}")
	List<String> getGender(@PathVariable String email) {
		return service.getGender(email);
	}
	
	
}
