package com.ibm.training.forTotalCal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/for-total-calories")
public class ForTotalCaloriesController {
	
	@Autowired
	ForTotalCaloriesService serv;
	
	@RequestMapping("/if-exists/{email}/{date}")
	Integer totalCaloriesExist(@PathVariable String email, @PathVariable String date) {
		return serv.totalCaloriesExist(email, date);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/users")
	void insertUserForTotalCalories(@RequestBody ForTotalCalories frTtlCal){
		serv.insertUserForTotalCalories(frTtlCal);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/users")
	void updateUserForTotalCalories(@RequestBody ForTotalCalories frTtlCal) {
		serv.updateUserForTotalCalories(frTtlCal);
	}
	
	@RequestMapping("/fetchForGraph/{email}")
	List<Integer> fetchCalories(@PathVariable String email ){
		return serv.fetchCalories(email);
	}
	
	@RequestMapping("/fetch-month/{email}/{month}")
	Integer fetchTotalCalByMonth(@PathVariable String email, @PathVariable int month){
		return serv.fetchTotalCalByMonth(email, month);
	}
	
	@RequestMapping("/fetch-progress/{email}/{month}")
	Integer fetchProgress(@PathVariable String email, @PathVariable int month){
		return serv.fetchProgress(email, month);
	}
	
	@RequestMapping("/fetch-total-day-wise/{email}/{month}/{year}")
	List<Integer> fetchTotalCalDayWise(@PathVariable String email, @PathVariable int month, @PathVariable int year){
		return serv.fetchTotalCalDayWise(email, month, year);
	}
	
	
}
