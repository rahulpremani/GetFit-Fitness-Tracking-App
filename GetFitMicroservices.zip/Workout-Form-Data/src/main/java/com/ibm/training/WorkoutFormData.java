package com.ibm.training;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class WorkoutFormData {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	
	String title, activity, email, date;
	int duration, calories, forDay, forMonth, forYear;
	public WorkoutFormData(String title, String activity, String email, String date, int duration, int calories,
			int forDay, int forMonth, int forYear) {
		this.title = title;
		this.activity = activity;
		this.email = email;
		this.date = date;
		this.duration = duration;
		this.calories = calories;
		this.forDay = forDay;
		this.forMonth = forMonth;
		this.forYear = forYear;
	}
	public WorkoutFormData() {
	
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getCalories() {
		return calories;
	}
	public void setCalories(int calories) {
		this.calories = calories;
	}
	public int getForDay() {
		return forDay;
	}
	public void setForDay(int forDay) {
		this.forDay = forDay;
	}
	public int getForMonth() {
		return forMonth;
	}
	public void setForMonth(int forMonth) {
		this.forMonth = forMonth;
	}
	public int getForYear() {
		return forYear;
	}
	public void setForYear(int forYear) {
		this.forYear = forYear;
	}

}
