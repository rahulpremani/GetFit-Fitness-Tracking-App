package com.ibm.training.forTotalCal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ForTotalCaloriesService {
	
	@Autowired
	 ForTotalCaloriesRepository repo;

	public Integer totalCaloriesExist(String email, String date) {
		return repo.checkIfTotalCaloriesExist(email, date);
	}

	public void insertUserForTotalCalories(ForTotalCalories frTtlCal) {
		repo.save(frTtlCal);
		
	}

	public void updateUserForTotalCalories(ForTotalCalories frTtlCal) {
			repo.updateUserCaloriesByEmailAndDate(frTtlCal.getTotalCalories(), frTtlCal.getEmail(), frTtlCal.getDate());
		
	}
	
	public List<Integer> fetchCalories(String email) {
		return repo.fetchCaloriesByEmail(email);
	}

	public Integer fetchTotalCalByMonth(String email, int month) {
		return repo.fetchTotalCalByMonth(email, month);
	}

	public Integer fetchProgress(String email, int month) {
		return repo.fetchProgressByMonth(email, month);
	}

	public List<Integer> fetchTotalCalDayWise(String email, int month, int year) {
		return repo.fetchTotalCalDayWise(email, month, year);
	}

}

