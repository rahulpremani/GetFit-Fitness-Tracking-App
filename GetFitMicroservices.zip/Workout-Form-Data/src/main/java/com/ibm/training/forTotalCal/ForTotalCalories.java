package com.ibm.training.forTotalCal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ForTotalCalories {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	String email, date;
	int totalCalories, month, year;
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	
	public ForTotalCalories(String email, String date, int totalCalories, int month, int year) {
		this.email = email;
		this.date = date;
		this.totalCalories = totalCalories;
		this.month = month;
		this.year = year;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getTotalCalories() {
		return totalCalories;
	}
	public void setTotalCalories(int totalCalories) {
		this.totalCalories = totalCalories;
	}
	
	
	
}
