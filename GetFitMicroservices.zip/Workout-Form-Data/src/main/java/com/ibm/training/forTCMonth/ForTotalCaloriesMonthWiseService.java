package com.ibm.training.forTCMonth;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ForTotalCaloriesMonthWiseService {
	
	@Autowired
	 ForTotalCaloriesMonthWiseRepository repo;

	public Integer totalCaloriesExist(String email, int month) {
		return repo.checkIfTotalCaloriesExistMonthWise(email, month);
	}

	public List<Integer> fetchTotalCalMonthWise(String email, int month) {
		return repo.fetchTotalCalMonthWise(email, month);
	}

	public void insertUserForTotalCaloriesMonthWise(ForTotalCaloriesMonthWise frTtlCal) {
		repo.save(frTtlCal);
		
	}

	public void updateUserForTotalCaloriesMonthWise(ForTotalCaloriesMonthWise frTtlCal) {
		repo.updateUserCaloriesByEmailAndMonth(frTtlCal.getTotalCalories(), frTtlCal.getEmail(), frTtlCal.getMonth());
		
	}

	
}

