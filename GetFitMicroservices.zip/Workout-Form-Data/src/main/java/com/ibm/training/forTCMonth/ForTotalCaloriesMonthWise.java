package com.ibm.training.forTCMonth;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ForTotalCaloriesMonthWise {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	
	String email;
	int totalCalories, year, month;
	
	public ForTotalCaloriesMonthWise() {
		
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getTotalCalories() {
		return totalCalories;
	}

	public void setTotalCalories(int totalCalories) {
		this.totalCalories = totalCalories;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public ForTotalCaloriesMonthWise(String email, int totalCalories, int month, int year) {
		this.email = email;
		this.totalCalories = totalCalories;
		this.month = month;
		this.year = year;
	}
	
	
}
