package com.ibm.training.forTCMonth;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/for-total-calories-month-wise")
public class ForTotalCaloriesMonthWiseController {
	
	@Autowired
	ForTotalCaloriesMonthWiseService serv;
	
	@RequestMapping("/if-exists/{email}/{month}")
	Integer totalCaloriesExistByMonth(@PathVariable String email, @PathVariable int month) {
		return serv.totalCaloriesExist(email, month);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/users")
	void insertUserForTotalCaloriesMonthWise(@RequestBody ForTotalCaloriesMonthWise frTtlCal){
		serv.insertUserForTotalCaloriesMonthWise(frTtlCal);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/users")
	void updateUserForTotalCaloriesMonthWise(@RequestBody ForTotalCaloriesMonthWise frTtlCal) {
		serv.updateUserForTotalCaloriesMonthWise(frTtlCal);
	}
	
	@RequestMapping("/fetch-total-month-wise/{email}/{year}")
	List<Integer> fetchTotalCalMonthWise(@PathVariable String email, @PathVariable int year){
		return serv.fetchTotalCalMonthWise(email, year);
	}
	
	
}
