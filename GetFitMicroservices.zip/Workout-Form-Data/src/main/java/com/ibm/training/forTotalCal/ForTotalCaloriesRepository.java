package com.ibm.training.forTotalCal;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ForTotalCaloriesRepository extends CrudRepository<ForTotalCalories, Integer> {

	@Query(value = "SELECT 1 FROM for_total_calories WHERE email = :email AND date = :date", nativeQuery = true)
	Integer checkIfTotalCaloriesExist(@Param(value = "email") String email, @Param(value = "date") String date);

	@Transactional
	@Modifying
	@Query(value = "update for_total_calories set total_calories = total_calories + :totalCalories "
			+ "where email = :email AND date = :date", nativeQuery = true)
	void updateUserCaloriesByEmailAndDate(@Param(value = "totalCalories") int totalCalories,
			@Param(value = "email") String email, @Param(value = "date") String date);

	@Query(value = "Select total_calories from for_total_calories where email =:email", nativeQuery = true)
	List<Integer> fetchCaloriesByEmail(String email);

	@Query(value = "Select SUM(total_calories) from for_total_calories where email =:email AND month = :month", nativeQuery = true)
	Integer fetchTotalCalByMonth(@Param(value = "email") String email, @Param(value = "month") int month );

	@Query(value = "SELECT COUNT(total_calories) FROM for_total_calories WHERE email = :email AND month = :month", nativeQuery = true)
	Integer fetchProgressByMonth(@Param(value = "email") String email,@Param(value = "month") int month);

	@Query(value = "SELECT total_calories FROM for_total_calories WHERE email = :email AND month = :month AND year = :year ", nativeQuery = true)
	List<Integer> fetchTotalCalDayWise(@Param(value = "email") String email, @Param(value = "month") int month, @Param(value = "year") int year);

}

