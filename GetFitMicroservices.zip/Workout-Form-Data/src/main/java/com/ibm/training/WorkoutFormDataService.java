package com.ibm.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WorkoutFormDataService {
	
	@Autowired
	 WorkoutFormDataRepository repo;
	
	public void  sendWorkoutFormData(WorkoutFormData workoutForm){
		repo.save(workoutForm);
	}

	public List<WorkoutFormData> getWorkoutData(String email) {
		return repo.findByEmail(email);
	}

}

