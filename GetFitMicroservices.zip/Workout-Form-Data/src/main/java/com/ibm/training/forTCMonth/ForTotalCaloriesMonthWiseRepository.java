package com.ibm.training.forTCMonth;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ForTotalCaloriesMonthWiseRepository extends CrudRepository<ForTotalCaloriesMonthWise, Integer> {

	@Query(value = "SELECT 1 FROM for_total_calories_month_wise WHERE email = :email AND month = :month", nativeQuery = true)
	Integer checkIfTotalCaloriesExistMonthWise(@Param(value = "email") String email, @Param(value = "month") int month);

	@Transactional
	@Modifying
	@Query(value = "update for_total_calories_month_wise set total_calories = total_calories + :totalCalories "
			+ "where email = :email AND month = :month", nativeQuery = true)
	void updateUserCaloriesByEmailAndMonth(@Param(value = "totalCalories") int totalCalories,
			@Param(value = "email") String email, @Param(value = "month") int month);

	@Query(value = "SELECT total_calories FROM for_total_calories_month_wise WHERE email = :email AND year = :year", nativeQuery = true)
	List<Integer> fetchTotalCalMonthWise(@Param(value = "email") String email,@Param(value = "year") int year);

}

