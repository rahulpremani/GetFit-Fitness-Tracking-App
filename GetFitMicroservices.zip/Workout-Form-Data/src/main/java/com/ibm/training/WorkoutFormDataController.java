package com.ibm.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WorkoutFormDataController {
	
	@Autowired
	WorkoutFormDataService serv;
	
	@RequestMapping(method = RequestMethod.POST, value = "/workoutFormData")
	void sendWorkoutFormData(@RequestBody WorkoutFormData workoutForm){
		serv.sendWorkoutFormData(workoutForm);
	}
	
	@RequestMapping("/getWorkoutData/{email}")
	List<WorkoutFormData> getWorkoutData(@PathVariable String email ){
		return serv.getWorkoutData(email);
	}
	
	
}
