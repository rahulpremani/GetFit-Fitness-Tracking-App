package com.exercise.demo.goals;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MyGoal {

	@Id
	String email;
	
	String bodyType, mode;
	int calories;
	public MyGoal(String email, String bodyType, String mode, int calories) {
		this.email = email;
		this.bodyType = bodyType;
		this.mode = mode;
		this.calories = calories;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getCalories() {
		return calories;
	}

	public void setCalories(int calories) {
		this.calories = calories;
	}

	public MyGoal() {
		
	}
 
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}
	
	
}
