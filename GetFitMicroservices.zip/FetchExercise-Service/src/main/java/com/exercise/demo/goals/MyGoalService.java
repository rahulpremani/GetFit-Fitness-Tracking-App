package com.exercise.demo.goals;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MyGoalService {

	@Autowired
	MyGoalRepository repo;

	public void insertGoal(MyGoal mygoal) {
		repo.save(mygoal);
		
	}

	public Integer fetchCalorie(String email) {
		
		return repo.findByEmail(email);
	}

	public List<String> fetchMode(String email) {
		return repo.fetchModeByEmail(email);
	}

	public List<String> fetchBodyType(String email) {
		return repo.fetchBodyTypeByEmail(email);
	}

	public Boolean goalExists(String email) {
		return repo.existsByEmail(email);
	}

}
