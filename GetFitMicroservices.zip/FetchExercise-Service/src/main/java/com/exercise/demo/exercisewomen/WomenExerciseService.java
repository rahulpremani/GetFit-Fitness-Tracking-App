package com.exercise.demo.exercisewomen;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WomenExerciseService {

	@Autowired
	WomenExerciseRepository repo;
	
	
	public List<String> getExercise(String bodyType) {
		return repo.findByBodyType(bodyType);
	}

}
