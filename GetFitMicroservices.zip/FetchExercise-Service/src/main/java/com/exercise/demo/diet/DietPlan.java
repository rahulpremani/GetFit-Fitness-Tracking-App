package com.exercise.demo.diet;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DietPlan {

	@Id
	int sNo;
	
	String diet, bodyType;

	public int getsNo() {
		return sNo;
	}

	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

	public String getDiet() {
		return diet;
	}

	public void setDiet(String diet) {
		this.diet = diet;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public DietPlan(int sNo, String diet, String bodyType) {

		this.sNo = sNo;
		this.diet = diet;
		this.bodyType = bodyType;
	}
	public DietPlan() {
		
	}
		
}
