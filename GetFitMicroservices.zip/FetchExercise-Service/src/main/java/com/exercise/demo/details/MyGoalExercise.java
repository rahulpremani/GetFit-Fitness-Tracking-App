package com.exercise.demo.details;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MyGoalExercise {

	@Id
	int sNo;
	
	String exercise, bodyType;

	public MyGoalExercise() {
	
	}

	public MyGoalExercise(int sNo, String exercise, String bodyType) {
		
		this.sNo = sNo;
		this.exercise = exercise;
		this.bodyType = bodyType;
	}

	public int getsNo() {
		return sNo;
	}

	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

	public String getExercise() {
		return exercise;
	}

	public void setExercise(String exercise) {
		this.exercise = exercise;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}
	
}
