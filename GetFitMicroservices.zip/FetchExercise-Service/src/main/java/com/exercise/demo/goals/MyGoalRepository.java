package com.exercise.demo.goals;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


public interface MyGoalRepository extends CrudRepository<MyGoal, String> {

	
	@Query(value="select calories from my_goal where email = :email", nativeQuery = true)
	Integer findByEmail(@Param(value = "email") String email);
	
	@Query(value="select mode from my_goal where email = :email", nativeQuery = true)
	List<String> fetchModeByEmail(@Param(value = "email") String email);
	
	@Query(value="select body_type from my_goal where email = :email", nativeQuery = true)
	List<String> fetchBodyTypeByEmail(@Param(value = "email") String email);
	
	Boolean existsByEmail(String email);
	
//	@Query(value="select exercise from my_goal_exercise where body_type = :body_type", nativeQuery = true)
//	List<String> findByBodyType(@Param(value = "body_type") String bodyType);
//	
}
