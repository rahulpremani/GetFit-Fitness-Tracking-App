package com.exercise.demo.diet;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fetch-diet")
public class DietController {

	@Autowired
	DietSevice serv;
	
	@RequestMapping("/diet/{bodyType}")
	List<String> getDiet(@PathVariable String bodyType){
		return serv.getDiet(bodyType);
	}
	
}
