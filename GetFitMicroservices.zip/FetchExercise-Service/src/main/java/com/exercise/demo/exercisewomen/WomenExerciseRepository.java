package com.exercise.demo.exercisewomen;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface WomenExerciseRepository extends CrudRepository<ExerciseWomen, Integer> {

	@Query(value="select exercise from exercise_Women where body_type = :body_type", nativeQuery = true)
	List<String> findByBodyType(@Param(value = "body_type") String bodyType);
	
}
