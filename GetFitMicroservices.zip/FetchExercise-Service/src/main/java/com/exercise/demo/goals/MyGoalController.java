package com.exercise.demo.goals;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/goals")
public class MyGoalController {

	@Autowired
	MyGoalService serv;
	
	@RequestMapping(method = RequestMethod.POST, value = "/goal")
	void insertGoal(@RequestBody MyGoal mygoal){
		
		serv.insertGoal(mygoal);
	}
	
	@RequestMapping("/goal/{email}")
	Integer fetchCalorie(@PathVariable String email){
		return serv.fetchCalorie(email);
	}
	
	@RequestMapping("/goal/getMode/{email}")
	List<String> fetchMode(@PathVariable String email){
		return serv.fetchMode(email);
	}
	
	@RequestMapping("/goal/get-body-type/{email}")
	List<String> fetchBodyType(@PathVariable String email){
		return serv.fetchBodyType(email);
	}
	
	@RequestMapping("/if-exists/{email}")
	Boolean goalExists(@PathVariable String email) {
		return serv.goalExists(email);
	}
	
	
}
