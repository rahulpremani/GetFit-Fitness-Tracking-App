package com.exercise.demo.diet;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface DietRepository extends CrudRepository<DietPlan, Integer> {

	@Query(value="select diet from diet_plan where body_type = :body_type", nativeQuery = true)
	List<String> findByBodyType(@Param(value = "body_type") String bodyType);
	
}
