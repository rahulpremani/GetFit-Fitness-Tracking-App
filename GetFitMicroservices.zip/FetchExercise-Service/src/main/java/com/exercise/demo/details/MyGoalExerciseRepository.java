package com.exercise.demo.details;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface MyGoalExerciseRepository extends CrudRepository<MyGoalExercise, Integer> {

	@Query(value="select exercise from my_goal_exercise where body_type = :body_type", nativeQuery = true)
	List<String> findByBodyType(@Param(value = "body_type") String bodyType);
	
}
