package com.exercise.demo.details;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fetch-exercise")
public class MyGoalExerciseController {

	@Autowired
	MyGoalExerciseService serv;
	
	@RequestMapping("/exercises/{bodyType}")
	List<String> getExercise(@PathVariable String bodyType){
		return serv.getExercise(bodyType);
	}
	
}
