package com.exercise.demo.diet;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DietSevice {

	@Autowired
	DietRepository repo;
	
	
	public List<String> getDiet(String bodyType) {
		return repo.findByBodyType(bodyType);
	}

}
