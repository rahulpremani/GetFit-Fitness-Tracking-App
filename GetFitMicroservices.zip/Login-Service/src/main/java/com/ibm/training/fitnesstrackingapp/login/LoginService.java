package com.ibm.training.fitnesstrackingapp.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class LoginService {

	@Autowired
	RestTemplate template;

	@Autowired
	LoginRepository repo;

	@Autowired
	BCryptPasswordEncoder encoder;

	String authenticateUser(User userCredentials) {

		User checkUser = repo.findByEmail(userCredentials.getEmail());

		if (checkUser != null) {
			if (encoder.matches(userCredentials.getPassword(), checkUser.getPassword())) {
				return "Success";
			} else {
				return "Invalid Password";
			}
		}
		return "User doesn't exist";
	}
	
}
