package com.ibm.training.fitnesstrackingapp.login;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface LoginRepository extends CrudRepository<User, String>{

	@Query(value = "Select email, password from user where email = ?1", nativeQuery = true)
	User findByEmail(String email);
}
