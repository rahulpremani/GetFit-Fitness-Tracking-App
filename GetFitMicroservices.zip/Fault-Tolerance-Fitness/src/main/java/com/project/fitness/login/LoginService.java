package com.project.fitness.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class LoginService {

	@Autowired
	RestTemplate template;

	@Autowired
	BCryptPasswordEncoder encoder;

//	@HystrixCommand(fallbackMethod = "fallbackForLogin")
//	@HystrixProperty(name = "hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds", value = "4000")
	@HystrixCommand(fallbackMethod = "fallbackForLogin", commandProperties = {
			@HystrixProperty(name = "execution.timeout.enabled", value = "false") })
	String authenticateUser(User userCredentials) {
		return template.postForObject("http://loginService/auth", userCredentials, String.class);
	}

	String fallbackForLogin(User userCredentials) {
		return "We're currently down because of a server issue, We're working to fix it, Inconvenience is regretted";
	}

}
