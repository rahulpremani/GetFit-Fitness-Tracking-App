package com.project.fitness.register;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.fitness.login.User;

@RestController
public class RegistrationController {

	@Autowired
	RegistrationService service;
	
	@Autowired
	BCryptPasswordEncoder encoder;
	
	@RequestMapping(method = RequestMethod.POST, value = "/userso")
	String registerUser(@RequestBody RegisterUser user){
		return service.registerUser(user);
	}

	
}
