package com.project.fitness.register;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class RegistrationService {
	
	@Autowired
	RestTemplate template;
	
	@HystrixCommand(fallbackMethod = "fallBackForRegister", commandProperties = {
			@HystrixProperty(name = "execution.timeout.enabled", value = "false") })
	public String registerUser(RegisterUser user) {
		
		return template.postForObject("http://registrationService/register/users", user , String.class);
	}
	
	String fallBackForRegister(RegisterUser user){
		return "We're currently down because of a server issue, We're working to fix it, Inconvenience is regretted";
	}

}
